# V17 changes

- Move the weekly weather view below the full clock/date row and render it as a rounded card.
- Use stable coordinates for Taoyuan, Taipei, New Taipei, Taichung, Tainan and Kaohsiung to avoid localized geocoder failures.
- Add QUERY_ALL_PACKAGES so Android 11+ can enumerate installed launcher apps for folder contents.
- Populate the System folder from installed system packages that have a launch intent, while respecting excluded packages.
- Keep the folder grid's existing app tiles, add tile and long-press actions.

Build note: Gradle wrapper requires Gradle 8.9 download; this environment could not reach services.gradle.org, so APK build was not completed locally.
